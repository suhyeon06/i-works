-- MySQL dump 10.13  Distrib 8.0.34, for Win64 (x86_64)
--
-- Host: localhost    Database: iworks
-- ------------------------------------------------------
-- Server version	8.0.35

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `department`
--

DROP TABLE IF EXISTS `department`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `department` (
  `department_id` int NOT NULL AUTO_INCREMENT,
  `department_is_used` bit(1) NOT NULL,
  `department_leader_id` int DEFAULT NULL,
  `department_created_at` datetime(6) NOT NULL,
  `department_updated_at` datetime(6) NOT NULL,
  `department_desc` varchar(255) DEFAULT NULL,
  `department_name` varchar(255) NOT NULL,
  `department_tel_first` varchar(255) DEFAULT NULL,
  `department_tel_last` varchar(255) DEFAULT NULL,
  `department_tel_middle` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`department_id`),
  UNIQUE KEY `UK_f5np34wnxt905fwmrs6133l28` (`department_name`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `department`
--

LOCK TABLES `department` WRITE;
/*!40000 ALTER TABLE `department` DISABLE KEYS */;
INSERT INTO `department` VALUES (1,_binary '',105,'2024-02-15 13:10:23.809689','2024-02-15 16:53:31.155152','인사부','인사','010','1234','1234'),(2,_binary '',17,'2024-02-15 13:10:25.884195','2024-02-16 02:20:17.722796','정총무','총무','02','1234','1234'),(3,_binary '',3,'2024-02-15 13:10:27.875833','2024-02-16 02:20:35.781904','회계부입니다.','회계','02','1111','1111'),(4,_binary '',19,'2024-02-15 13:10:29.850955','2024-02-16 02:20:50.771866','좋은 기획할게요','기획','02','1111','1231'),(5,_binary '',105,'2024-02-15 13:10:31.836459','2024-02-16 02:21:12.837781','iworks 개발팀','개발','02','0000','0000'),(6,_binary '\0',9,'2024-02-15 17:23:35.141364','2024-02-15 22:13:12.880020','비서실입니다.','비서실','111','1111','11');
/*!40000 ALTER TABLE `department` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-02-16 10:16:52
